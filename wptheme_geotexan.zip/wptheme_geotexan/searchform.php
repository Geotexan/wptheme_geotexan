<form class="search" action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
  <input class="bt-search margin-top-6" type="image" src="<?php bloginfo("stylesheet_directory");?>/img/xlupa.png">
  <input name="s" class="search-box margin-left-3 margin-top-0" type="text" value="" placeholder="Buscar">
</form>